package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.HandlerThread;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    EditText editTex;
    TextView t1,t2,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTex=(EditText)findViewById(R.id.editText);

    }

    public void weather(View view){

        download d=new download();
        Log.i("city",editTex.getText().toString());
        d.execute("https://openweathermap.org/data/2.5/weather?q="+editTex.getText().toString()+"&appid=b6907d289e10d714a6e88b30761fae22");
    }

    public class download extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String... urls) {

            String result="";
            URL url;
            HttpURLConnection urlConnection;
            try{
                url=new URL(urls[0]);
                urlConnection=(HttpURLConnection)url.openConnection();
                InputStream in=urlConnection.getInputStream();
                InputStreamReader reader=new InputStreamReader(in);
                int data=reader.read();

                while(data!=-1){
                    char current=(char)data;
                    result+=current;
                    data=reader.read();
                }
                return result;
            }catch(Exception e){
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
           // Log.i("weatherInfo",s);
            t1=(TextView)findViewById(R.id.textView);
            t2=(TextView)findViewById(R.id.textView3);
            t3=(TextView)findViewById(R.id.textView4);

            try {
                JSONObject jsonObject = new JSONObject(s);
                String weather = jsonObject.getString("weather");
                String temperature=jsonObject.getString("main");
                Log.i("main",temperature);
                JSONArray arr=new JSONArray(weather);
                JSONObject j2=new JSONObject(temperature);
                Log.i("Temperature",j2.getString("temp"));
                //int t=Integer.parseInt(j2.getString("temp"));
                t3.setText(j2.getString("temp")+"°C");
                for(int i=0;i<arr.length();i++){
                    JSONObject jpart=arr.getJSONObject(i);
                    Log.i("Main",jpart.getString("main"));
                    Log.i("Description",jpart.getString("description"));
                    t1.setText(jpart.getString("main"));
                    t2.setText(jpart.getString("description"));
                }

                /*for(int j=0;j<arr2.length();j++){
                    JSONObject jpart2=arr2.getJSONObject(j);
                    Log.i("Temeperature",jpart2.getString("temp"));
                    int t1=Integer.parseInt(jpart2.getString("temp"));
                    t3.setText(Integer.toString(t1)+"°C");
                }*/

            }catch(Exception e){
                e.printStackTrace();
            }

        }
    }




}
